SpeQ Mathematics Croatian usersguide and program language (Hrvatski)

Both language file and usersguide are translated by Hasan Osmanagic.

To install this language and usersguide, unzip the contents of 
this zipfile in the program folder of SpeQ Mathematics, typically:

    C:\Program Files\SpeQ Mathematics\

There are two main files in this zip file: Hrvatski.chm and Hrvatski.ini.
These files will be extracted respectively into the subfolders \usersguide 
and \language.

After you start up SpeQ again, you can choose your language in the 
Settings window under the tab "Language".

Jos de Jong,
www.speqmath.com
