SpeQ Mathematics Hellenic (Greek) usersguide and program language

Both language file and usersguide are translated by Nikolopoulos Ioannis.

To install this language and usersguide, unzip the contents of 
this zipfile in the program folder of SpeQ Mathematics, typically:

    C:\Program Files\SpeQ Mathematics\

There are two main files in this zip file: Hellenic.chm and Hellenic.ini.
These files will be extracted respectively into the subfolders \usersguide 
and \language.

After you start up SpeQ again, you can choose your language in the 
Settings window under the tab "Language".

Jos de Jong,
www.speqmath.com
