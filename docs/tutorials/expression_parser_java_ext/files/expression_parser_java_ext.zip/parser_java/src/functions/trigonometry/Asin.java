package functions.trigonometry;

import functions.Function;
import parser.Error;

public class Asin extends Function {
    /**
     * Constructor.
     */
	public Asin() {
    }
    
    /**
     * Constructor.
     * This function requires one parameter and calculates Asin(x)
     * @param x
     */    
	public Asin(Function x) {
        set(x);
    }

    /**
     * Evaluate the function
     * @return    The result of the function
     */
    public double eval() throws Error {
        if (values_.size() != 1) {
            throw new Error(8, name()); // wrong number of parameters
        }

        return Math.asin(values_.get(0).eval());        
    }
    
    /**
     * Return the name of the function
     */
    public String name() {
        return "Asin";
    }
}
