#!/bin/sh

xterm -e "java -jar parser.jar"

