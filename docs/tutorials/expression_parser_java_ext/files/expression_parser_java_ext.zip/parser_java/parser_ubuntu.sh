#!/bin/sh

gnome-terminal -e "java -jar parser.jar"

