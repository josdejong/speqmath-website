
#ifndef FUNCTIONS_H
#define FUNCTIONS_H


using namespace std;

double factorial(double value);
double sign(double value);

#endif
