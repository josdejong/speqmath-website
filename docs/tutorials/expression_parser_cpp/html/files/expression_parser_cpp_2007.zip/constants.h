

#ifndef CONSTANTS_H
#define CONSTANTS_H

const int NAME_LEN_MAX = 30;
const int EXPR_LEN_MAX = 255;
const int ERR_LEN_MAX = 255;

#endif
