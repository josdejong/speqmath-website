Beeper service
Demo C++ windows service application

This code example demonstrates how to run a program as a windows service. 
A service runs in the background of Windows, even if nobody is logged in 
on the computer or server. 

Usage of the beeper service program:
Open a command prompt and go to the directory containing the service. Then enter
one of the following commands:
   beeper_service.exe install
   beeper_service.exe uninstall
   beeper_service.exe start
   beeper_service.exe stop
   beeper_service.exe restart
   beeper_service.exe state
   beeper_service.exe help
To manage the state and properties of all of your Windows services, enter:
   services.msc

Jos de Jong, 2009
