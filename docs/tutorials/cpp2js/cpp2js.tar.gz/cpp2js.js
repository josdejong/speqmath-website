/**
 * @file cpp2js.js
 * 
 * @brief 
 * cpp2js is a tool which allows you to embed native C++ methods inside 
 * javascript. The tool is able to compile and execute embedded C++ code on the 
 * server side.
 * Defining and calling C++ methods can be done both via synchronous and 
 * asynchronous calls to the server.
 * 
 * @license
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy 
 * of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 *
 * Copyright © 2011 Jos de Jong
 *
 * @author  Jos de Jong, <wjosdejong@gmail.com>
 * @date    2011-01-09
 */

var CGI_URL = "/cgi-bin/";

/*
TODO

  parse the response value into the right data type
*/


/**
 * Compile native C++ code on the server side. 
 * 
 * When no callback method is provided, the method waits until the server
 * returns the compiled method, and in turn returns this method. In case of 
 * an compilation error, an error is thrown. 
 * 
 * When a callback method is provided, the method sends the compilation request 
 * asyncroneously to the server, and directly returns. Once the server retruns
 * the compiled method, the callback function is called with two parameters, 
 * func and error: 
 *   callback(func, error)
 * when the compilation was succesfull, the parameter func contains the method
 * When an compilation error ooccured, func is undefined, and error contains
 * the error message.
 * 
 * The created javascript method can be called synchronously or 
 * asynchronously.
 *
 * @param {string} code      A C++ method
 * @param {method} callback  Optional
 * @return {method} method   Compiled method, or zero if a callback method is
 *                           provided.
 */ 
function cpp2js (code, callback) {
  // parse the code to get the function name and the parameters
  var functionName = "";
  var parameterNames = new Array();
  var eof = '';
  var i = 0;
  var c = code.charAt(0);

  // skip whitespaces
  while (c == ' ' || c == '\t' || c == '\r') {
    c = code.charAt(++i); // read next char
  }    
  
  // read return type
  var returnType = "";
  while (c != ' ' && c != '\t' && c != '\r' && c != eof) {
    returnType += c;
    
    c = code.charAt(++i); // read next char
  }
  
  // skip whitespaces
  while (c == ' ' || c == '\t' || c == '\r') {
    c = code.charAt(++i); // read next char
  }

  // read function name
  functionName = "";
  while (c != ' ' && c != '\t' && c != '\r' && c != '(' && c != eof) {
    functionName += c;
    c = code.charAt(++i); // read next char
  }

  // skip whitespaces and parenthesis
  while (c == ' ' || c == '\t' || c == '\r' || c == '(') {
    c = code.charAt(++i); // read next char
  }

  // read all parameters
  while (c != ')' && c != eof) {
    // skip whitespaces
    while (c == ' ' || c == '\t' || c == '\r') {
      c = code.charAt(++i); // read next char
    }    
    
    // read parameter type
    var parameterType = "";
    while (c != ' ' && c != '\t' && c != '\r' && c != eof) {
      parameterType += c;
      c = code.charAt(++i); // read next char
    }

    // skip whitespaces
    while (c == ' ' || c == '\t' || c == '\r') {
      c = code.charAt(++i); // read next char
    }    
    
    // read parameter name
    var parameterName = "";
    while (c != ' ' && c != '\t' && c != '\r' && c != ',' && c != ')' && c != eof) {
      parameterName += c;
      c = code.charAt(++i); // read next char
    }
    parameterNames.push(parameterName);

    // skip whitespaces and comma
    while (c == ' ' || c == '\t' || c == '\r' || c == ',') {
      c = code.charAt(++i); // read next char
    }
  }

  var compileCallback = function (response) {
    if (response.indexOf("cpp2js_") == 0) {
      // succesfull compilation

      var fn = function () {
        var argv = fn.arguments;
        var argc = argv.length;

        if (argc > 0 && typeof argv[argc-1] == "function") {
          var callback = argv[argc-1];
          argc--;
        }
        else  {
          var callback = undefined;        
        }

        var url = CGI_URL + response + "?";
        for (var p = 0; p < parameterNames.length && p < argc; p++) {
          if (p > 0)
            url += "&";
          url += parameterNames[p] + "=" + encodeURIComponent(argv[p]);      
        } 

        var ajax = new Ajax();
        if (callback != undefined)
          ajax.Request("GET", url, callback); // asynchronous call
        else 
          return ajax.Request("GET", url); // synchronous call
      }
      
      if (callback != undefined)
        callback(fn);
      else 
        return fn;
    }
    else {
      // compilation error
      if (callback != undefined)
        callback(undefined, response);
      else 
        throw response;
    }
  }
  
  // Send request to compile the code
  var encodedCode = encodeURIComponent(code);
  var ajax = new Ajax();
  if (callback != undefined) {
    ajax.Request("GET", CGI_URL + "cpp2js?" + encodedCode, compileCallback); // async
  }
  else {
    result = ajax.Request("GET", CGI_URL + "cpp2js?" + encodedCode); // synchronous call
    return compileCallback(result);
  }
}


/**
 * @class Ajax
 * 
 * Perform asynchronous calls to the server
 */ 
var Ajax = function () {
  this.updating = false;  
}
Ajax.prototype.Request = function(method, url, callback) 
{
  var async = (callback != undefined)
  var me = this;
  
  this.isUpdating = true;
  this.request = (window.XMLHttpRequest) ? 
    new XMLHttpRequest() : 
    new ActiveXObject("MSXML2.XMLHTTP"); 

  if (async)  {
    this.callbackMethod = callback; 
    this.request.onreadystatechange = function() { me.checkReadyState(); }; 
  }
  this.request.open(method, url, async); 
  this.request.send(url); 
  
  if (!async) {
    return this.request.responseText;
  }
}
Ajax.prototype.checkReadyState = function(_id) 
{ 
  switch(this.request.readyState) 
  { 
    case 1: break; 
    case 2: break; 
    case 3: break; 
    case 4: 
      this.isUpdating = false; 
      this.callbackMethod(this.request.responseText);
      break; 
  } 
} 
 
