#!/usr/bin/python

import cgi, cgitb 


# Create instance of FieldStorage 
form = cgi.FieldStorage() 

name = form.getvalue('name')
if not name:
  name = 'World'

print "Content-type:text/html\r\n\r\n"
print "<html>"
print "<head>"
print "<title>Hello %s - First Python CGI Program</title>" % name
print "</head>"
print "<body>"
print "<h2>Hello %s!</h2>" % name
print "This is my first Python CGI program<br>"

for i in range(0, 9):
  print i, "<br />"

print "</body>"
print "</html>"
