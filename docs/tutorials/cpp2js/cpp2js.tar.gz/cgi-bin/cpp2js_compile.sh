#!/bin/sh

g++ -Wall -s -o cpp2js cpp2js.cpp md5.cpp decode.cpp
