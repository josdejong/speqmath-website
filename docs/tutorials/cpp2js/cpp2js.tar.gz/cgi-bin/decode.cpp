#include "decode.h"

/**
 returns the decimal value of the provided char containing a hex value like 'D'
 */
int hex2dec(const char c)
{
  if (c == 0) return 0;

  char str[] = "0123456789ABCDEF";
  char* pch = static_cast<char*>(memchr(str, c, strlen(str)));
  if (pch)
  {
    return pch - str;
  }
  else
  {
    return 0;
  }
}

/**
Decode url
@param url          encoded url
@return decodedUrl  decoded url
*/
char* decode(const char* url)
{
  int maxlen = strlen(url);
  const char *uRaw = url;
  char* decodedUrl = new char[maxlen+1];
  char *d = decodedUrl;
  int len = 0;

  while (*uRaw != '\0' && len < maxlen)
  {
    char c = *uRaw;

    if (c == '%')
    {
      // this is a special html character like "%20"
      const char* s = uRaw;
      s++; char c1 = *s;
      s++; char c2 = *s;

      c = (hex2dec(c1) << 4) + hex2dec(c2);
      if (c != '\0')
      {
        uRaw += 2;
      }
    }
    *d = c;
    d++;    
    
    uRaw++;
    len++;
  }
  *d = '\0';

  return decodedUrl;
}
