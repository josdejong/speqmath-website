/**
 * @file cpp2js.cpp
 * 
 * @brief 
 * cpp2js is a tool which allows you to embed native C++ methods inside 
 * javascript. The tool is able to compile and execute embedded C++ code on the 
 * server side.
 * Defining and calling C++ methods can be done both via synchronous and 
 * asynchronous calls to the server.
 * 
 * @license
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy 
 * of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 *
 * Copyright © 2011 Jos de Jong
 *
 * @author  Jos de Jong, <wjosdejong@gmail.com>
 * @date    2011-01-09
 */

/**
 * Inline c compiler
 * 
 * TODO
 *   Handle function definitions with const, like "string function(const string test) {"
 *   improve the url decoding method, make it faster and smaller
 *   Handle arrays
 *   FastCGI implementation?
 *   Safety? risks?
 */
 
#include <cstdlib> 
#include <cstdio> 
#include <cstring>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>

#include "md5.h"
#include "decode.h"

using namespace std;


/**
 * Create the return call for the specified return type
 */ 
string createReturnCall(string returnType) { 
  if (returnType == "bool") return "printf(\"%d\", result);";
  if (returnType == "int") return "printf(\"%d\", result);";
  if (returnType == "long") return "printf(\"%ld\", result);";
  if (returnType == "float") return "printf(\"%f\", result);";
  if (returnType == "double") return "printf(\"%f\", result);";
  if (returnType == "char") return "printf(\"%c\", result);";
  if (returnType == "string") return "printf(\"%s\", result.c_str());";
  if (returnType == "void") return "";
  
  return "  printf(\"Error: Unsupported returnType '" + returnType + "'\");";
}

/**
 * Get the correct conversion function to convert from char* to the given type
 */ 
string getConversionFunction(string parameterType) { 
  if (parameterType == "bool") return "atoi";
  if (parameterType == "int") return "atoi";
  if (parameterType == "long") return "atol";
  if (parameterType == "float") return "atof";
  if (parameterType == "double") return "atof";
  if (parameterType == "char") return "";
  if (parameterType == "string") return "";
  
  // TODO: error in case of unknown type?
  return "";
}


/**
 * create a C++ program from the given code
 */ 
void writeCode(const char code[]) 
{
  // parse the code to get the function name and the parameters
  string returnType;
  string functionName;
  vector<string> parameterTypes;
  vector<string> parameterNames;
  char eof = '\0';
  int i = 0;
  char c = code[i];

  // skip whitespaces
  while (c == ' ' || c == '\t' || c == '\r') {
    c = code[++i];
  } 
  
  // read return type
  returnType = "";
  while (c != ' ' && c != '\t' && c != '\r' && c != eof) {
    returnType += c;
    c = code[++i];
  }
  
  // skip whitespaces
  while (c == ' ' || c == '\t' || c == '\r') {
    c = code[++i];
  }

  // read function name
  functionName = "";
  while (c != ' ' && c != '\t' && c != '\r' && c != '(' && c != eof) {
    functionName += c;
    c = code[++i];
  }

  // skip whitespaces and parenthesis
  while (c == ' ' || c == '\t' || c == '\r' || c == '(') {
    c = code[++i];
  }

  // read all parameters
  while (c != ')' && c != eof) {
    // skip whitespaces
    while (c == ' ' || c == '\t' || c == '\r') {
      c = code[++i];
    }    
    
    // read parameter type
    string parameterType;
    while (c != ' ' && c != '\t' && c != '\r' && c != eof) {
      parameterType += c;
      c = code[++i];
    }
    parameterTypes.push_back(parameterType);

    // skip whitespaces
    while (c == ' ' || c == '\t' || c == '\r') {
      c = code[++i];
    }    
    
    // read parameter name
    string parameterName;
    while (c != ' ' && c != '\t' && c != '\r' && c != ',' && c != ')' && c != eof) {
      parameterName += c;
      c = code[++i];
    }
    parameterNames.push_back(parameterName);

    // skip whitespaces and comma
    while (c == ' ' || c == '\t' || c == '\r' || c == ',') {
      c = code[++i];
    }
  }

  // calculate the MD5 of the code, used as filename
  const char* md5code = MD5String(code);
  if (md5code == 0)
    cout << "Error: failed to generate MD5 of code"; 
  string md5 = string("cpp2js_") + md5code;
  string filename = md5 + ".cpp";
  
  // check if the file already exists
  ifstream testfile(md5.c_str());
  if (testfile.is_open()) 
  { 
    testfile.close(); 

    cout << md5;
    return;
  }

  ofstream file(filename.c_str());
  if (file.is_open()) 
  {
    // write the head of the program
    file << 
      "#include <cstdio>\n"   // TODO: determine the needed libraries from the code? import more libraries by default?
      "#include <cstdlib>\n"
      "#include <cstring>\n"
      "#include <cmath>\n"
      "#include <string>\n"
      "#include <iostream>\n"
      "#include <vector>\n"
      "#include \"decode.h\"\n"
      "\n"
      "using namespace std;      \n"
      "\n";    

    // write the actual code
    file << code;      

    file << 
      "\n"
      "int main(int argc, char *argv[])\n"
      "{\n"
      "  printf(\"Content-Type: text/html\\n\\n\");\n";       
    
    // get query string
    file <<
      "  char* query = getenv(\"QUERY_STRING\");\n"
      "  if (query == 0) {"
          "printf(\"Error: No query data provided\"); return 0;"
        "}\n";
    file << "\n";

    // write initialization of the parameters
    for (unsigned int p = 0; p < parameterNames.size(); p++) {
      file << "  char* " + parameterNames[p] + " = 0;\n";
    }
    file << "\n";

    // retrieve the parameter values
    file <<
    "  char* pch = strtok (query, \"&=\");\n"
    "  while (pch != 0)\n"
    "  {\n";
    for (unsigned int p = 0; p < parameterNames.size(); p++) {
      file <<  "    if (strcmp(pch, \"" << parameterNames[p] << "\") == 0) " <<
        parameterNames[p] <<" = decode(strtok (0, \"&=\"));\n";
    }
    file <<
      "    pch = strtok (0, \"&=\");\n"
      "  }\n";

    file << "\n";
    for (unsigned int p = 0; p < parameterNames.size(); p++) {
      file << "  if (" << parameterNames[p] << " == 0) {"
        "printf(\"Error: Parameter '" << parameterNames[p] << "' missing\"); "
        "return 0;}\n";
    }    
    file << "\n";
    
    // the function call
    file << "  ";
    if (returnType != "void")
      file << returnType << " result = ";
    file << functionName << "(";
    for (unsigned int p = 0; p < parameterNames.size(); p++) {
      if (p > 0)
        file << ",";

      file << getConversionFunction(parameterTypes[p]) << "(" <<
        parameterNames[p] << ")";
    }
    file << ");\n";
    
    string returnCall = createReturnCall(returnType);

    // write the end of the program
    file <<
      "  " + returnCall + "\n"
      "  return 0;\n"
      "}\n";

    file.close();
    
    // Compile the code. Write any compiler output to a logfile
    string compileStr = 
      "g++ -Wall -s -o "
      "\"" + md5 + "\" "
      "\"" + md5 + ".cpp\" "
      "\"decode.cpp\" "
      "2> \"" + md5 + ".log\"";
    int result = system(compileStr.c_str());
    
    // Retrieve the compilation errors from the log file and return them
    if (result == 0) 
    {
      // success!
      cout << md5;
      return;
    }
    else
    { 
      cout << "Error: Compliation errors in the C++ code\n";
      
      string logfilename = md5 + ".log";
      ifstream log(logfilename.c_str());
      if (log.is_open()) {
        string line;
        while ( log.good() )
        {
          getline (log, line);
          // TODO: adjust line numbers in the error messages
          cout << line << endl;
        }
        log.close();        
      } else {
        cout << "Error: unknown errors (no log file available)";
      }
    }
  }
  else
  {
    cout << "Error writing code to file\n";
  }
}


int main(int argc, char *argv[])
{
  // tell the server what kind of content you are sending
  printf("Content-Type: text/html\n\n");
  
  // get data.
  // the data is posted in an url like:
  //   http://www.mysite.com/cgi-bin/helloname.cgi?name=jos
  char* rawurl = getenv("QUERY_STRING");
  if (rawurl != 0)
  {
    // decode the url
    char* url = decode(rawurl);

    // write the code to a file
    writeCode(url);
  }
  else
  {
    printf("Error: No data provided.\n"); // TODO
  }
 
  return EXIT_SUCCESS;
}


