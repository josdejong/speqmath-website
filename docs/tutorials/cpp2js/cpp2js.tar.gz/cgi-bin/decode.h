
#include <cstring>

int hex2dec(const char c);
char* decode(const char* url);

