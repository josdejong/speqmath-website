/***************************************************************
 * Name:      sqlite_export_guiApp.h
 * Purpose:   Defines Application Class
 * Author:    Jos de Jong ()
 * Created:   2010-05-15
 * Copyright: Jos de Jong ()
 * License:
 **************************************************************/

#ifndef APP_H
#define APP_H

#include <wx/app.h>

class App : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // APP_H
