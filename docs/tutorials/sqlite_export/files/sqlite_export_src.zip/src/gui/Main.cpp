/***************************************************************
 * Name:      sqlite_export_guiMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    Jos de Jong ()
 * Created:   2010-05-15
 * Copyright: Jos de Jong ()
 * License:
 **************************************************************/

/**
TODO:
- Execute the export as thread
*/

#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#include "Main.h"


BEGIN_EVENT_TABLE(Main, wxFrame)
    EVT_CLOSE       (Main::OnClose)
    EVT_BUTTON      (ID_BUTTON_DATABASE,  Main::btnDatabaseClick)
    EVT_BUTTON      (ID_BUTTON_OUTPUT,    Main::btnOutputClick)
    EVT_BUTTON      (ID_BUTTON_EXPORT,    Main::btnExportClick)
    EVT_TEXT        (ID_TEXT_DATABASE,    Main::txtDatabaseUpdated)
    EVT_TEXT        (ID_TEXT_OUTPUT,      Main::txtOutputUpdated)
    EVT_COMBOBOX    (ID_COMBO_MODE,       Main::cmbModeUpdated)
    EVT_RADIOBUTTON (ID_RADIO_TABLE,      Main::tableSelected)
    EVT_RADIOBUTTON (ID_RADIO_SQL,        Main::sqlSelected)
    EVT_COMBOBOX    (ID_COMBO_TABLE,      Main::tableSelected)
    EVT_TEXT        (ID_COMBO_TABLE,      Main::tableSelected)
    EVT_TEXT        (ID_TEXT_SQL,         Main::sqlSelected)
END_EVENT_TABLE()

Main::Main(wxFrame *frame, const wxString& title, const wxPoint pos, const wxSize size)
    : wxFrame(frame, -1, title, pos, size)
{
  settingsFilename = "settings.ini";
  const int margin = 10; // pixels
  loaded = false;

  Centre();
  panel = new wxPanel(this, -1);
  sizer = new wxBoxSizer(wxHORIZONTAL);
  panel->SetSizer(sizer);

  grid = new wxFlexGridSizer(3, margin, margin);
  sizer->Add(grid, 1, wxEXPAND | wxALL, margin);
  grid->AddGrowableCol(1, 0);  // auto size the textboxes in the second column
  grid->AddGrowableRow(5, 0);  // auto size the textbox sql vertiacally

  boxDatabase = new wxStaticText(panel, -1, _("Database"));
  txtDatabase = new wxTextCtrl(panel, ID_TEXT_DATABASE, _(""));
  btnDatabaseBrowse = new wxButton(panel, ID_BUTTON_DATABASE, _("Browse..."));
  grid->Add(boxDatabase, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);
  grid->Add(txtDatabase, 1, wxGROW);
  grid->Add(btnDatabaseBrowse, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);

  boxOutput = new wxStaticText(panel, -1, _("Output file"));
  txtOutput = new wxTextCtrl(panel, ID_TEXT_OUTPUT, _(""));
  btnOutputBrowse = new wxButton(panel, ID_BUTTON_OUTPUT, _("Browse..."));
  grid->Add(boxOutput, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);
  grid->Add(txtOutput, 1, wxGROW);
  grid->Add(btnOutputBrowse, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);

  wxString modeDefault = _("xls");
  wxArrayString modes;
  modes.Add(_("tabs"));
  modes.Add(_("csv"));
  modes.Add(_("xls"));
  modes.Add(_("html"));
  boxMode = new wxStaticText(panel, -1, _("Mode"));
	cmbMode = new wxComboBox(panel, ID_COMBO_MODE, modeDefault, wxDefaultPosition, wxDefaultSize, modes, wxCB_READONLY, wxDefaultValidator);
	boxModeFake = new wxStaticText(panel, -1, _(""));
  grid->Add(boxMode, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);
  grid->Add(cmbMode, 1, wxGROW);
  grid->Add(boxModeFake, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);

  wxStaticText* boxSelection = new wxStaticText(panel, -1, _("Selection"));
  grid->Add(boxSelection, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);
  grid->Add(new wxStaticText(panel, -1, _("")), 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);
  grid->Add(new wxStaticText(panel, -1, _("")), 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);

  wxString tableDefault = _("");
  wxArrayString tables;
  radTable = new wxRadioButton(panel, ID_RADIO_TABLE, _("Table"), wxDefaultPosition, wxDefaultSize, wxRB_GROUP);
	cmbTable = new wxComboBox(panel, ID_COMBO_TABLE, tableDefault, wxDefaultPosition, wxDefaultSize, tables, wxCB_READONLY, wxDefaultValidator);
	boxTableFake = new wxStaticText(panel, -1, _(""));
  grid->Add(radTable, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);
  grid->Add(cmbTable, 1, wxGROW);
  grid->Add(boxTableFake, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);

  radSql = new wxRadioButton(panel, ID_RADIO_SQL, _("Custom SQL"));
  txtSql = new wxTextCtrl(panel, ID_TEXT_SQL, _(""), wxDefaultPosition, wxSize(150, 24), wxTE_MULTILINE);
  boxSqlFake = new wxStaticText(panel, -1, _(""));
  grid->Add(radSql, 1, wxALIGN_LEFT);
  grid->Add(txtSql, 1, wxGROW);
  grid->Add(boxSqlFake, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);

  boxExportFake = new wxStaticText(panel, -1, _(""));
  boxExportStatus = new wxStaticText(panel, -1, _(""));
  btnExport = new wxButton(panel, ID_BUTTON_EXPORT, _("Export"));
  grid->Add(boxExportFake, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);
  grid->Add(boxExportStatus, 1, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);
  grid->Add(btnExport, 0, wxALIGN_LEFT | wxALIGN_CENTER_VERTICAL);

  databaseBrowse = 0;
  outputBrowse = 0;

  loaded = true;
  Layout();  // resize all controls

  settings.load(settingsFilename);
  SetControlsText();
}

Main::~Main()
{
}

string Main::toString(const wxString str)
{
  return string((const char*)str.mb_str(wxConvUTF8));
}

wxString Main::toWxString(const string str)
{
  return wxString(str.c_str(), wxConvUTF8);
}


/**
 * put settings values on screen in the controls
 */
void Main::SetControlsText()
{
  txtDatabase->SetValue(toWxString(settings.database));
  txtOutput->SetValue(toWxString(settings.output));
  cmbMode->SetValue(toWxString(settings.mode));
  cmbTable->SetValue(toWxString(settings.table));
  txtSql->SetValue(toWxString(settings.sql));
  radTable->SetValue(settings.tableSelected);
}


/**
 * Read values from screen and save it in the settings file
 */
void Main::GetControlsText()
{
  settings.database = toString(txtDatabase->GetValue());
  settings.output = toString(txtOutput->GetValue());
  settings.mode = toString(cmbMode->GetValue());
  settings.table = toString(cmbTable->GetValue());
  settings.sql = toString(txtSql->GetValue());
  settings.tableSelected = radTable->GetValue();
}



void Main::OnClose(wxCloseEvent &event)
{
  GetControlsText();
  settings.save(settingsFilename);

  Destroy();
}

void Main::btnDatabaseClick(wxCommandEvent& event)
{
  if (databaseBrowse == 0)
    databaseBrowse = new wxFileDialog(this, _("Select a SQLite database"),  _(""), _(""), _(""), wxFD_OPEN);

  int ret = databaseBrowse->ShowModal();
  if (ret == wxID_OK)
  {
    wxString filename = databaseBrowse->GetPath();
    txtDatabase->SetValue(filename);
  }
}

void Main::btnOutputClick(wxCommandEvent& event)
{
  if (outputBrowse == 0)
    outputBrowse = new wxFileDialog(this, _("Choose an output filename"), _(""), _(""), _(""), wxFD_SAVE);

  int ret = outputBrowse->ShowModal();
  if (ret == wxID_OK)
  {
    wxString filename = outputBrowse->GetPath();
    txtOutput->SetValue(filename);
  }
}


// after the database filename is changed, check if the file exists and if so,
// read the tables in the database
void Main::txtDatabaseUpdated(wxCommandEvent& event)
{
  GetTables();
}

// when output name changed, adjust mode accordingly to extension
void Main::txtOutputUpdated(wxCommandEvent& event)
{
  GuessMode();
}

// when output name changed, adjust mode accordingly to extension
void Main::cmbModeUpdated(wxCommandEvent& event)
{
  AdjustExtension();
}


// Guess the right mode from the extension of the output filename
void Main::GuessMode()
{
  if (!loaded) return;

  wxString output = txtOutput->GetValue();
  wxString extension;

  unsigned dot = output.rfind('.');
  if (dot != wxString::npos)
  {
    extension = output.Right(output.Length() - dot - 1);
    extension.MakeLower();

    if (extension == _("txt") || extension == _("dat") || extension == _("tab")) cmbMode->SetValue(_("tabs"));
    if (extension == _("csv")) cmbMode->SetValue(_("csv"));
    if (extension == _("xls")) cmbMode->SetValue(_("xls"));
    if (extension == _("html") || extension == _("htm")) cmbMode->SetValue(_("html"));
  }
}

// adjust the extension of the output after the mode is changed
void Main::AdjustExtension()
{
  if (!loaded) return;

  wxString mode = cmbMode->GetValue();
  wxString output = txtOutput->GetValue();
  wxString extension;

  unsigned dot = output.rfind('.');
  if (dot != wxString::npos)
  {
    extension = output.Right(output.Length() - dot - 1);
    output    = output.erase(dot);
    extension.MakeLower();
  }

  if (mode == _("tabs"))
  {
    if (extension != _("txt") && extension != _("dat") && extension != _("tab"))
      txtOutput->SetValue(output + _(".txt"));
  }
  else if (mode == _("csv"))
  {
    if (extension != _("csv"))
      txtOutput->SetValue(output + _(".") + mode);
  }
  else if (mode == _("xls"))
  {
    if (extension != _("xls"))
      txtOutput->SetValue(output + _(".") + mode);
  }
  else if (mode == _("html"))
  {
    if (extension != _("html") && extension != _("htm"))
      txtOutput->SetValue(output + _(".") + mode);
  }
}


// Get all tables from the currently selected database
void Main::GetTables()
{
  if (!loaded) return;

  wxString database = txtDatabase->GetValue();
  SqliteExport* se = new SqliteExportTabs();

  // Delete all choises from combo
  cmbTable->Clear();

  // Retrieve all tables from database
  vector<string> tables = se->GetTables((const char*)database.mb_str(wxConvUTF8));
  for (unsigned i = 0; i < tables.size(); i++)
  {
    wxString table(tables[i].c_str(), wxConvUTF8);
    cmbTable->Append(table);
  }

  delete se;
  se = 0;
}

// Set selection to the Table radio button
void Main::tableSelected(wxCommandEvent& event)
{
  radTable->SetValue(true);
}

// Set selection to the Custom SQL radio button
void Main::sqlSelected(wxCommandEvent& event)
{
  radSql->SetValue(true);
}

void Main::SetStatus(const bool busy)
{
  bool enabled = !busy;

  txtDatabase->Enable(enabled);
  txtOutput->Enable(enabled);
  cmbMode->Enable(enabled);
  cmbTable->Enable(enabled);
  txtSql->Enable(enabled);
  radTable->Enable(enabled);
  radSql->Enable(enabled);

  btnDatabaseBrowse->Enable(enabled);
  btnOutputBrowse->Enable(enabled);
  btnExport->Enable(enabled);

  if ( busy)
  {
    btnExport->SetLabel(_("Busy..."));
  }
  else
  {
    btnExport->SetLabel(_("Export"));
  }

  Layout();
}

void Main::btnExportClick(wxCommandEvent& event)
{
  char database[MAXLEN] = "";
  char output[MAXLEN] = "";
  char mode[MAXLEN] = "";
  char query[MAXLEN] = "";

  // save the settings
  GetControlsText();
  settings.save(settingsFilename);

  strncpy(database, (const char*)txtDatabase->GetValue().mb_str(wxConvUTF8), MAXLEN);
  strncpy(output,   (const char*)txtOutput->GetValue().mb_str(wxConvUTF8), MAXLEN);
  strncpy(mode,     (const char*)cmbMode->GetValue().mb_str(wxConvUTF8), MAXLEN);

  if (radTable->GetValue())
  {
    char table[MAXLEN] = "";
    strncpy(table, (const char*)cmbTable->GetValue().mb_str(wxConvUTF8), MAXLEN);
    sprintf(query, "SELECT * FROM '%.255s';", table);
  }
  if (radSql->GetValue())
  {
    strncpy(query, (const char*)txtSql->GetValue().mb_str(wxConvUTF8), MAXLEN);
  }

  // check for errors
  if (strcmp(database, "") == 0)
  {
    wxMessageBox(_("Error: no database name provided."), _("Error"), wxICON_EXCLAMATION);
    return;
  }
  if (strcmp(output, "") == 0 and strcmp(mode, "screen") != 0)
  {
    wxMessageBox(_("Error: no output filename provided."), _("Error"), wxICON_EXCLAMATION);
    return;
  }
  if (strcmp(mode, "") == 0)
  {
    wxMessageBox(_("Error: no mode provided nor detected from output filename."), _("Error"), wxICON_EXCLAMATION);
    return;
  }
  if (strcmp(query, "") == 0)
  {
    wxMessageBox(_("Error: no table name or sql query provided."), _("Error"), wxICON_EXCLAMATION);
    return;
  }

  // Set status busy
  SetStatus(true);

  bool success = false;
  SqliteExport* se = 0;

  if (strcmp(mode, "tabs") == 0)   se = new SqliteExportTabs();
  if (strcmp(mode, "csv") == 0)    se = new SqliteExportCsv();
  if (strcmp(mode, "xls") == 0)    se = new SqliteExportXls();
  if (strcmp(mode, "html") == 0)   se = new SqliteExportHtml();

  // execute the export
  success = se->DoExport (database, output, query);

  // Set status not busy
  SetStatus(false);

  if (success)
    wxMessageBox(_("The export is succesfully executed."), _("Done"), wxICON_INFORMATION);
  else
    wxMessageBox(wxString(se->LastError(), wxConvUTF8), _("Error"), wxICON_EXCLAMATION);

  delete se;
  se = 0;

}
