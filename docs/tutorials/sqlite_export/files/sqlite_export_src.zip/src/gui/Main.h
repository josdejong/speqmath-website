/***************************************************************
 * Name:      Main.h
 * Purpose:   Defines Application Frame
 * Author:    Jos de Jong ()
 * Created:   2010-05-15
 * Copyright: Jos de Jong ()
 * License:
 **************************************************************/

#ifndef MAIN_H
#define MAIN_H

#ifndef WX_PRECOMP
    #include <wx/wx.h>
#endif

#include "../SqliteExport.h"
#include "Settings.h"

using namespace std;

class Main: public wxFrame
{
public:
  Main(wxFrame *frame, const wxString& title, const wxPoint pos = wxDefaultPosition, const wxSize size = wxSize(500, 300));
  ~Main();

private:
  enum
  {
    ID_TEXT_DATABASE,
    ID_TEXT_OUTPUT,
    ID_COMBO_TABLE,
    ID_COMBO_MODE,
    ID_TEXT_SQL,
    ID_RADIO_TABLE,
    ID_RADIO_SQL,
    ID_BUTTON_DATABASE,
    ID_BUTTON_OUTPUT,
    ID_BUTTON_EXPORT,

    ID_DUMMY_VALUE_ //don't remove this value unless you have other enum values
  };

  // controls
  wxPanel *panel;
  wxBoxSizer* sizer;
  wxFlexGridSizer* grid;

  wxStaticText* boxDatabase;
  wxTextCtrl* txtDatabase;
  wxButton* btnDatabaseBrowse;

  wxStaticText* boxOutput;
  wxTextCtrl* txtOutput;
  wxButton* btnOutputBrowse;

  wxStaticText* boxMode;
	wxComboBox* cmbMode;
	wxStaticText* boxModeFake;

  wxRadioButton* radTable;
	wxComboBox* cmbTable;
	wxStaticText* boxTableFake;

  wxRadioButton* radSql;
  wxTextCtrl* txtSql;
  wxStaticText* boxSqlFake;

  wxStaticText* boxExportFake;
  wxStaticText* boxExportStatus;
  wxButton* btnExport;

  wxFileDialog* databaseBrowse;
  wxFileDialog* outputBrowse;

  bool loaded;
  string settingsFilename;
  Settings settings;

  // events;
  void OnClose(wxCloseEvent& event);
  void btnDatabaseClick(wxCommandEvent& event);
  void btnOutputClick(wxCommandEvent& event);
  void btnExportClick(wxCommandEvent& event);
  void txtDatabaseUpdated(wxCommandEvent& event);
  void txtOutputUpdated(wxCommandEvent& event);
  void cmbModeUpdated(wxCommandEvent& event);
  void tableSelected(wxCommandEvent& event);
  void sqlSelected(wxCommandEvent& event);

  void SetStatus(const bool busy);
  void SetControlsText();
  void GetControlsText();
  void GetTables();
  void GuessMode();
  void AdjustExtension();

  string toString(const wxString str);
  wxString toWxString(const string str);

  DECLARE_EVENT_TABLE()
};


#endif // SQLITE_EXPORT_GUIMAIN_H
