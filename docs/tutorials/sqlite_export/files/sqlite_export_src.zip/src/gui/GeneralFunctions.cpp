
#include "GeneralFunctions.h"



/**
 * check if given file exists and is readable
 * @param fileName  the name of the file
 * @return          true if the file exists. Else false
 */
bool fileExists(const char* fileName)
{
  // will not work if you do not have read permissions
  // to the file, but if you don't have read, it
  // may as well not exist to begin with.
  bool success = false;

  FILE* fp = 0;
  fp = fopen(fileName, "rb");
  if(fp != 0)
  {
    fclose(fp);
    success = true;
  }
  return success;
}


/**
 * check if given file exists and is readable
 * @param fileName  the name of the file
 * @return          true if the file exists. Else false
 */
bool fileExists(const string& fileName)
{
  return fileExists(fileName.c_str());
}



/**
 * Returns a string with the current date/time.
 * Returns a string with format "yyyy-mm-dd hh:mm:ss"
 */
string getCurrentDatetime()
{
  time_t t = time(0);
  tm time = *localtime(&t);

  // reformat the datetime to "yyyy-mm-dd hh:mm:ss"
  char timeChar[20];
  sprintf(timeChar,
          "%04i-%02i-%02i %02i:%02i:%02i",
          time.tm_year + 1900,
          time.tm_mon + 1,
          time.tm_mday,
          time.tm_hour,
          time.tm_min,
          time.tm_sec);

  return string(timeChar);
}


/**
 * Returns a string with the current date.
 * Returns a string with format "2008-10-23"
 */
string getCurrentDate()
{
  time_t t = time(0);
  tm time = *localtime(&t);

  char dateChar[20];
  sprintf(dateChar, "%04i-%02i-%02i", time.tm_year + 1900, time.tm_mon + 1, time.tm_mday);
  string dateString = dateChar;
  return dateString;
}


/**
 * Returns a string with the current Year and month.
 * Returns a string with format "2008-10"
 */
string getCurrentYearMonth()
{
  time_t t = time(0);
  tm time = *localtime(&t);

  char dateChar[20];
  sprintf(dateChar, "%04i-%02i", time.tm_year + 1900, time.tm_mon + 1);
  string dateString = dateChar;
  return dateString;
}


/**
 * Returns a string with the current time.
 * Returns a string with format "17:23:01"
 */
string getCurrentTime()
{
  char timeChar[20];

  time_t t = time(0);
  tm time = *localtime(&t);

  sprintf(timeChar, "%02i:%02i:%02i", time.tm_hour, time.tm_min, time.tm_sec);
  string timeString = timeChar;
  return timeString;
}




/**
 * Returns the name of the currently running program
 * @param path    a path with program name, such as "C:\programs\wComm.exe"
 * @return        pointer to the program name only, for example "wComm.exe"
 */
const char* getProgramName(const char* path)
{
  const char* p = strrchr(path, '\\');
  if (p != 0)
  {
    p++;
  }
  else
  {
    p = path;
  }
  return p;
}


/**
 * Split up a string with commands in a vector with the command names and values.
 * The commands are separated by a semicolon ";". The command names and values
 * are separated by an equality character "=". The command value may be enclosed
 * by single "'" or double """ quotes.
 * For example command is a string like
 *    "Printer=\\wints\myprinter;command="^XA ^FO50,50 ^ADN,36,20 ^FDHello there!^FS ^XZ;""
 * Or
 *    "Server=quookerserver;username=myname;password=1234;database=myDb;"
 * @param     command   a string containing one or more commands
 * @return
 */
vector<Command> splitCommands(const string command)
{
  string commandList = command;
  string commandSeparator = ";";
  string valueSeparator = "=";

  vector<Command> commandVector;

  unsigned int c = string::npos;
  while ((c = commandList.find(commandSeparator)) != string::npos ||
         commandList.empty() == false)
  {
    if (c == string::npos)
    {
      // no ending semicolon
      c = commandList.length();
    }

    // check if the found commandSeparator is not inside a quoted command value.
    bool isInsideQuotes = false;
    unsigned int posQuoteStart = commandList.find("'");
    if (posQuoteStart != string::npos)
    {
      unsigned int posQuoteEnd = commandList.find("'", posQuoteStart + 1);
      if (posQuoteEnd != string::npos &&
          posQuoteStart < c && posQuoteEnd > c)
      {
        isInsideQuotes = true;
      }
    }
    posQuoteStart = commandList.find("\"");
    if (posQuoteStart != string::npos)
    {
      unsigned int posQuoteEnd = commandList.find("\"", posQuoteStart + 1);
      if (posQuoteEnd != string::npos &&
          posQuoteStart < c && posQuoteEnd > c)
      {
        isInsideQuotes = true;
      }
    }

    if (isInsideQuotes == false)
    {
      // split command
      string commandItem;
      if (c < commandList.length())
      {
        commandItem = commandList.substr(0, c);
        commandList = commandList.substr(c + 1);
      }
      else
      {
        commandItem = commandList;
        commandList = "";
      }

      // remove remarks from commandItem
      unsigned remark = string::npos;
      remark = commandItem.find("//");
      if (remark == string::npos) remark = commandItem.find("#");
      if (remark != string::npos)
      {
        // check whether the remark is found at the start of the line or after a space or tab
        if (remark == 0 || commandItem[remark - 1] == ' ' || commandItem[remark - 1] == '\t')
        {
          commandItem.erase(remark);
        }
      }
      commandItem = trim(commandItem);

      if (commandItem.empty() == false)
      {
        // split command name and value
        Command newCommand;

        int v = commandItem.find(valueSeparator);
        newCommand.name = commandItem.substr(0, v);
        newCommand.value = commandItem.substr(v + 1);

        newCommand.name = trim(newCommand.name);
        newCommand.value = trim(newCommand.value);

        if (newCommand.value[0] == '\'' || newCommand.value[0] == '\"')
        {
          newCommand.valueType = COMMAND_STRING;
        }
        else
        {
          newCommand.valueType = COMMAND_VALUE;
        }

        // remove enclosing quotes
        newCommand.value = removeQuotes(newCommand.value);
        commandVector.push_back(newCommand);

        //printf("command: {%s=%s}\n", newCommand.name.c_str(), newCommand.value.c_str());
      }
    }
  }

  return commandVector;
}


/**
 * Return the command value from the provided command name, to be found in
 * command vector. Finding the command name is case insensitive.
 * @param commandVector   a vector containing a list of command names and values
 * @param commandName     the name of the command to be found. Case insensitive
 * @param commandValue    the found value will be stored here in the string
 * @return                true if succesfull, else false.
 */
bool getCommandValue(const vector<Command>& commandVector, const string commandName, string& commandValue)
{
  bool success = false;
  string commandNameU = ucase(commandName);

  for (unsigned int i = 0; i < commandVector.size(); i++)
  {
    if (ucase(commandVector[i].name) == commandNameU)
    {
      // command name found
      commandValue = commandVector[i].value;
      success = true;
      break;
    }
  }
  return success;
}

/**
 * Return the command value from the provided command name, to be found in
 * command vector. Finding the command name is case insensitive.
 * @param commandVector   a vector containing a list of command names and values
 * @param commandName     the name of the command to be found. Case insensitive
 * @param commandValue    the found value will be stored here in an int
 * @return                true if succesfull, else false.
 */
bool getCommandValue(const vector<Command>& commandVector, const string commandName, int& commandValue)
{
  bool success = false;
  string commandNameU = ucase(commandName);

  for (unsigned int i = 0; i < commandVector.size(); i++)
  {
    if (ucase(commandVector[i].name) == commandNameU)
    {
      // command name found
      commandValue = toInt(commandVector[i].value);
      success = true;
      break;
    }
  }
  return success;
}

/**
 * Return the command value from the provided command name, to be found in
 * command vector. Finding the command name is case insensitive.
 * @param commandVector   a vector containing a list of command names and values
 * @param commandName     the name of the command to be found. Case insensitive
 * @param commandValue    the found value will be stored here in an int
 * @return                true if succesfull, else false.
 */
bool getCommandValue(const vector<Command>& commandVector, const string commandName, unsigned& commandValue)
{
  bool success = false;
  string commandNameU = ucase(commandName);

  for (unsigned int i = 0; i < commandVector.size(); i++)
  {
    if (ucase(commandVector[i].name) == commandNameU)
    {
      // command name found
      commandValue = toInt(commandVector[i].value);
      success = true;
      break;
    }
  }
  return success;
}


/**
 * Return the command value from the provided command name, to be found in
 * command vector. Finding the command name is case insensitive.
 * @param commandVector   a vector containing a list of command names and values
 * @param commandName     the name of the command to be found. Case insensitive
 * @param commandValue    the found value will be stored here in an int
 * @return                true if succesfull, else false.
 */
bool getCommandValue(const vector<Command>& commandVector, const string commandName, float& commandValue)
{
  bool success = false;
  string commandNameU = ucase(commandName);

  for (unsigned int i = 0; i < commandVector.size(); i++)
  {
    if (ucase(commandVector[i].name) == commandNameU)
    {
      // command name found
      commandValue = toFloat(commandVector[i].value);
      success = true;
      break;
    }
  }
  return success;
}

/**
 * Return the command value from the provided command name, to be found in
 * command vector. Finding the command name is case insensitive.
 * @param commandVector   a vector containing a list of command names and values
 * @param commandName     the name of the command to be found. Case insensitive
 * @param commandValue    the found value will be stored here in a bool
 * @return                true if succesfull, else false.
 */
bool getCommandValue(const vector<Command>& commandVector, const string commandName, bool& commandValue)
{
  bool success = false;
  string commandNameU = ucase(commandName);

  for (unsigned int i = 0; i < commandVector.size(); i++)
  {
    if (ucase(commandVector[i].name) == commandNameU)
    {
      // command name found
      commandValue = toBool(commandVector[i].value);
      success = true;
      break;
    }
  }
  return success;
}


/**
 * Remove spaces and tabs from the left side of the
 * provided string
 * @param s   string to get a left trim
 * @return    string without spaces and tabs at the left side
 */
string triml(const string& s)
{
  string sTrim = s;
  int pos(0);
  for ( ; sTrim[pos]==' ' || sTrim[pos]=='\t'; ++pos );
  sTrim.erase(0, pos);
  return sTrim;
}

/**
 * Remove spaces and tabs from the right side of the
 * provided string
 * @param s   string to get a right trim
 * @return    string without spaces and tabs at the right side
 */
string trimr(const string& s)
{
  string sTrim = s;
  int pos(sTrim.size());
  for ( ; pos && sTrim[pos-1]==' ' || sTrim[pos-1]=='\t'; --pos );
  sTrim.erase(pos, sTrim.size()-pos);
  return sTrim;
}

/**
 * Remove spaces and tabs from the both sides of the provided string
 * @param s   string to get a trim
 * @return    string without spaces and tabs at start and end
 */
string trim(const string& s)
{
  return triml(trimr(s));
}

/**
 * Make the provided string lowercase
 * @param   string which will be made lowercase
 * @return  the lowercase string
 */
string lcase(const string& str)
{
  string strLower = str;
  transform(strLower.begin(),
            strLower.end(),
            strLower.begin(),
            tolower);
  return strLower;
}

/**
 * Make the provided string uppercase
 * @param   string which will be made uppercase
 * @return  the uppercase string
 */
string ucase(const string& str)
{
  string strUpper = str;
  transform(strUpper.begin(),
            strUpper.end(),
            strUpper.begin(),
            toupper);
  return strUpper;
}

/**
 * Create a string consisting of num number of spaces
 * if num < 0 the function returns an empty string
 * @param num   the desired number of spaces
 * @return      a string with num spaces
 */
string space(const int num)
{
  string spaces;
  for (int i = 0; i < num; i++)
  {
    spaces += " ";
  }
  return spaces;
}

/**
 * Convert char to string
 */
string toString(const char* value)
{
  if (value != 0)
  {
    return string(value);
  }
  else
  {
    return string();
  }
}


/**
 * Convert bool to string ("0" or "1")
 */
string toString(const bool value)
{
  char str[10] = "";
  sprintf(str, "%i", value);
  return str;
}


/**
 * Convert bool to string ("True" or "False")
 */
string boolToString(const bool value)
{
  if (value == true)
  {
    return "True";
  }
  else
  {
    return "False";
  }
}


/**
 * Convert int to string
 */
string toString(const int value, const string& format)
{
  char str[10] = "";
  sprintf(str, format.c_str(), value);
  return str;
}

/**
 * Convert unsigned int to string
 */
string toString(const unsigned value)
{
  char str[20] = "";
  sprintf(str, "%u", value);
  return str;
}

/**
 * Convert int to string
 */
string toString(const long value)
{
  char str[20] = "";
  sprintf(str, "%li", value);
  return str;
}


/**
 * Convert float to string
 */
string toString(const float value)
{
  char str[20] = "";
  sprintf(str, "%g", value);
  return str;
}


/**
 * Convert float to string
 */
string toString(const double value)
{
  char str[20] = "";
  sprintf(str, "%g", value);
  return str;
}


/**
 * Convert string like "True" tool boolean value
 * if the string is not recognized, the function returns false
 */
bool toBool(const char* value)
{
  if (value == 0)
  {
    return false;
  }

  char valueU[5];
  strncpy(valueU, value, 5);
  for (int i = 0; i < 5; i++)
  {
    valueU[i] = toupper(valueU[i]);
  }

  return (strcmp("TRUE", valueU) == 0 || strcmp("1", valueU) == 0);
}

/**
 * Convert string  to an integer value
 */
int toInt(const char* value)
{
  if (value == 0)
  {
    return 0;
  }

  return atoi(value);
}


/**
 * Convert string to a float value
 * maximum length may be 255 characters
 * if the string is not recognized, the function returns false
 */
float toFloat(const char* value)
{
  if (value == 0)
  {
    return 0.0;
  }

  char* dot = strchr(value, ',');

  if (dot != 0)
  {
    char valueF[255];
    strncpy(valueF, value, 255);
    dot = strchr(valueF, ',');
    dot[0] = '.';
    return static_cast<float>(atof(valueF));
  }
  else
  {
    return static_cast<float>(atof(value));
  }
}


/**
 * Convert string to a double value
 * if the string is not recognized, the function returns false
 */
double toDouble(const char* value)
{
  if (value == 0)
  {
    return 0.0;
  }

  char* dot = strchr(value, ',');

  if (dot != 0)
  {
    char valueF[255];
    strncpy(valueF, value, 255);
    dot = strchr(valueF, ',');
    dot[0] = '.';
    return static_cast<double>(atof(valueF));
  }
  else
  {
    return static_cast<double>(atof(value));
  }
}



/**
 * Convert string like "True" tool boolean value
 * if the string is not recognized, the function returns false
 */
bool toBool(const string& value)
{
  string valueU = ucase(value);
  return (valueU == "TRUE" || valueU == "1");
}

/**
 * Convert string  to an integer value
 */
int toInt(const string& value)
{
  return atoi(value.c_str());
}


/**
 * Convert string to a float value
 * if the string is not recognized, the function returns false
 */
float toFloat(const string& value)
{
  string valueF = replace(value, ",", ".");
  return static_cast<float>(atof(valueF.c_str()));
}


/**
 * Convert string to a double value
 * if the string is not recognized, the function returns false
 */
double toDouble(const string& value)
{
  string valueF = replace(value, ",", ".");
  return atof(valueF.c_str());
}

/**
 * converts a given char string with hexadecimal values to a decimal value
 */
long hex2dec(const char hex[])
{
    return strtol(hex, NULL, 16);
}

/**
 * converts a given decimal value to a string containing the hexadecimal value
 */
void hex2dec(const char hex[], long &dec)
{
    dec = strtol(hex, NULL, 16);
}

void dec2hex(const long dec, char hex[])
{
    sprintf(hex, "%li", dec);
}


/**
 * Replace all occurances of the string search in str with replacement
 *
 */
string replace(const string& str, const string& match, const string& replacement)
{
  string strR = str;
  unsigned int i = string::npos;
  while ((i = strR.find(match, i + 1)) != string::npos)
  {
    strR.replace(i, match.length(), replacement);
    i += replacement.length() - match.length();
  }

  return strR;
}



/**
 * Remove enclosing quotes from the string.
 * Both single and double quotes are removed from start and end of the string.
 * @param str   string from which to remove the quotes
 * @return      string without leading/trailing quotes
 */
string removeQuotes(const string& str)
{
  // remove enclosing quotes
  string strClean = str;

  if ((strClean[0] == '\"' && strClean[strClean.length()-1] == '\"') ||
      (strClean[0] == '\'' && strClean[strClean.length()-1] == '\''))
  {
    strClean.erase(strClean.length() - 1);
    strClean.erase(0, 1);
  }

  return strClean;
}


