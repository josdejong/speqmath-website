
#include "Settings.h"


/**
 * Constructor
 */
Settings::Settings()
{
  // default program settings
  database = "example.db";
  output = "addresses.xls";
  mode = "xls";
  table = "addresses";
  sql = "";
  tableSelected = true;
}


/**
 * Load the settings from the file "settings.ini"
 * @param filename   Filename of the file containing the settings
 * @return success   true if succesfully loaded, else false.
 */
bool Settings::load(const string& filename)
{
  bool success = false;
  string params;

  FILE* file = fopen (filename.c_str(), "r");

  if (file != 0)
  {
    while (!feof(file))
    {
      char c = fgetc (file);
      params += c;
    }

    fclose(file);

    params = replace(params, "\r", "");
    params = replace(params, "\n", ";");

    string sqlSafe;
    vector<Command> paramList = splitCommands(params);
    getCommandValue(paramList, "database",  database);
    getCommandValue(paramList, "output",  output);
    getCommandValue(paramList, "mode",  mode);
    getCommandValue(paramList, "table",  table);
    getCommandValue(paramList, "sql",  sqlSafe);
    getCommandValue(paramList, "tableSelected",  tableSelected);

    sql = resolveSafeString(sqlSafe);

    success = true;
  }
  else
  {
    success = false;
  }

  return success;
}



/**
 * Save the current settings from the file "settings.ini"
 * @return  true if succesfully saved, else false.
 */
bool Settings::save(const string& filename)
{
  int failCount = 0;
  bool success = false;

  FILE* file = fopen (filename.c_str(), "w");

  if (file != 0)
  {
    fprintf(file,
      "# SQLITE EXPORT SETTINGS\n"
      "\n");

    string sqlSafe = safeString(sql);

    fprintf(file, "database = %s\n", database.c_str());
    fprintf(file, "output = %s\n", output.c_str());
    fprintf(file, "mode = %s\n", mode.c_str());
    fprintf(file, "table = %s\n", table.c_str());
    fprintf(file, "sql = %s\n", sqlSafe.c_str());
    fprintf(file, "tableSelected = %i\n", tableSelected);

    fclose(file);

    success = (failCount == 0);
  }
  else
  {
    success = false;
  }

  return success;
}

// resolve the escape characters in the string
string Settings::resolveSafeString(string strSafe)
{
  // read the sql string and replace "\n" and "\\" with a real return and slash
  string str;
  for (string::iterator i = strSafe.begin(); i != strSafe.end(); i++)
  {
    char c = *i;
    if (c == '\\')
    {
      string::iterator inext = i + 1;
      if (*inext == '\\')     {str += '\\'; i++;}
      else if (*inext == 'n') {str += '\n'; i++;}
      else {str += c;}
    }
    else
    {
      str += c;
    }
  }

  return str;
}

// create a safe string with escape characters for \ and \n
string Settings::safeString(string str)
{
  string strSafe;
  for (string::iterator i = str.begin(); i != str.end(); i++)
  {
    char c = *i;
    if (c == '\n')      strSafe += "\\n";
    else if (c == '\\') strSafe += "\\\\";
    else                strSafe += c;
   }
   return strSafe;
}

