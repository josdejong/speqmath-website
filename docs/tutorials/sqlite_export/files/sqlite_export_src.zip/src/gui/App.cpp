/***************************************************************
 * Name:      sqlite_export_guiApp.cpp
 * Purpose:   Code for Application Class
 * Author:    Jos de Jong ()
 * Created:   2010-05-15
 * Copyright: Jos de Jong ()
 * License:
 **************************************************************/

#ifdef WX_PRECOMP
#include "wx_pch.h"
#endif

#ifdef __BORLANDC__
#pragma hdrstop
#endif //__BORLANDC__

#include "App.h"
#include "Main.h"

IMPLEMENT_APP(App);

bool App::OnInit()
{
    Main* frame = new Main(0L, _("SQLite Export"));
    frame->SetIcon(wxICON(downloaddatabase));

    frame->Show();

    return true;
}
