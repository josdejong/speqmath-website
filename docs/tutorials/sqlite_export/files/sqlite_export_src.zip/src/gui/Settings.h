/**
 * class Settings
 *
 * This class contains all program settings. The class initializes the default
 * values of all settings and has functions to load / save the settings to
 * a file.
 */


#ifndef SETTINGS_H
#define SETTINGS_H

#include <string>

#include "GeneralFunctions.h"


using namespace std;


class Settings
{
public:
  Settings();
  bool load(const string& settings);
  bool save(const string& settings);

private:
  string resolveSafeString(string strSafe);
  string safeString(string str);

public:
  // data
  string database;
  string output;
  string mode;
  string table;
  string sql;
  bool tableSelected;
};


#endif

