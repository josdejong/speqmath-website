/**
To use these general functions you have to link to the following library:
  shlwapi
*/


#include <string>
#include <vector>
#include <algorithm>
#include <dir.h>
#include <dirent.h>
#include <sys/stat.h>
#include "windows.h"
#include "shlwapi.h"  // for function PathRemoveFileSpec()


#ifndef GENERALFUNCTIONS_H
#define GENERALFUNCTIONS_H

using namespace std;


bool fileExists(const char* FileName);
bool fileExists(const string& fileName);

// functions to spit commands
enum COMMAND_TYPE {COMMAND_VALUE, COMMAND_STRING};
class Command
{
  public:
    string name;
    string value;
    COMMAND_TYPE valueType;
};
vector<Command> splitCommands(const string command);
bool getCommandValue(const vector<Command>& commandVector, const string commandName, string& commandValue);
bool getCommandValue(const vector<Command>& commandVector, const string commandName, float& commandValue);
bool getCommandValue(const vector<Command>& commandVector, const string commandName, int& commandValue);
bool getCommandValue(const vector<Command>& commandVector, const string commandName, unsigned& commandValue);
bool getCommandValue(const vector<Command>& commandVector, const string commandName, bool& commandValue);

// string functions
string triml(const string& s);
string trimr(const string& s);
string trim(const string& s);
string lcase(const string& str);
string ucase(const string& str);
string space(const int num);
string removeQuotes(const string& str);

string toString(const char* value);
string toString(const bool value);
string boolToString(const bool value);
string toString(const int value, const string& format = "%i");
string toString(const unsigned value);
string toString(const long value);
string toString(const float value);
string toString(const double value);

bool   toBool(const string& value);
int    toInt(const string& value);
float  toFloat(const string& value);
double toDouble(const string& value);

bool   toBool(const char* value);
int    toInt(const char* value);
float  toFloat(const char* value);
double toDouble(const char* value);


long hex2dec(const char hex[]);
void dec2hex(const long dec, char hex[]);

string replace(const string& str, const string& match, const string& replacement);

#endif // GENERALFUNCTIONS_H
