/**
sqlite_export

This program enables you to easily export data from an sqlite to tabs, csv,
xls, or html format.
*/


#include <stdio.h>
#include <cstring>

#include "SqliteExport.h"


void printHelp()
{
  printf(
"SQLiteExport\n"
"\n"
"SQLiteExport is a command line program to easily export data from an SQLite\n"
"database. You can enter database, outputfile name and output type, and specify\n"
"a table or a custom sql command.\n"
"SQLiteExport is available for Linux and Windows.\n"
"\n"
"FEATURES\n"
"\n"
"Export from a SQLite database\n"
"Export formats: tabs, csv, xls, html\n"
"Export a complete table \n"
"Export results from a custom sql command\n"
"\n"
"USAGE\n"
"\n"
"sqlite_export -database DATABASE -output FILENAME -table TABLENAME [-mode MODE]\n"
"sqlite_export -database DATABASE -output FILENAME -sql SQLCOMMAND  [-mode MODE]\n"
"sqlite_export -help\n"
"\n"
"Available parameters:\n"
"-database DATABASE      The name of the SQLite database.\n"
"-output FILENAME        The filename of the output file.\n"
"-table TABLENAME        Table name of the table to be exported.\n"
"-sql SQLCOMMAND         A custom sql command\n"
"-mode MODE              The output format, optional. If mode is not provided,\n"
"                        the program guesses the right mode based on the \n"
"                        extension of the filename. For MODE, choose from:\n"
"                          tabs    A tab separated file\n"
"                          csv     A command separated file\n"
"                          xls     An Excel file\n"
"                          html    A html file\n"
"                          screen  Put results on screen\n"
"-help                   If parameter -help is provided, information about \n"
"                        the usage is printed.\n"
"\n"
"You have to choose one of the two parameters -table or -sql. \n"
"If one of the parameter values contains spaces, enclose the parameter value \n"
"with double quotes.\n"
"\n"
"EXAMPLE USAGE\n"
"\n"
"sqlite_export -database data.db -output myoutput.xls -table mytable\n"
"sqlite_export -database data.db -output data.csv -sql \"SELECT * FROM mytable;\"\n"
"sqlite_export -database data.db -output page.html -table adresses\n"
"sqlite_export -database \"other database.db\" -table adresses -mode screen \n"
"sqlite_export -help\n"
"\n"
"ABOUT\n"
"\n"
"Created with C++ and the Codeblocks IDE.\n"
"Created by Jos de Jong, 2010\n"
  );
}

int main(int argc, char **argv)
{
  const char* database = "";
  const char* output = "";
  const char* mode = "";
  const char* table = "";
  const char* sql = "";

  // check for help request
  for (int arg = 0; arg < argc; arg++)
  {
    if (strcmp(argv[arg], "-help") == 0)
    {
      printHelp();
      return 0;
    }
  }

  // retrieve parameters from program arguments
  for (int arg = 1; arg < argc - 1; arg++)
  {
     if (strcmp(argv[arg], "-database") == 0) database = argv[arg + 1];
     if (strcmp(argv[arg], "-output") == 0)   output = argv[arg + 1];
     if (strcmp(argv[arg], "-mode") == 0)     mode = argv[arg + 1];
     if (strcmp(argv[arg], "-table") == 0)    table = argv[arg + 1];
     if (strcmp(argv[arg], "-sql") == 0)      sql = argv[arg + 1];
  }

  // detect mode from output if mode is not provided
  if (strcmp(mode, "") == 0)
  {
    const char* dot = strrchr(output, '.');
    if (dot != 0)
    {
      dot++;
      mode = dot;
      if (strcmp(mode, "txt") == 0) mode = "tabs";
      if (strcmp(mode, "dat") == 0) mode = "tabs";
      if (strcmp(mode, "htm") == 0) mode = "html";
    }
  }

  // print information on the screen
  printf("SQLite Export\n\n");
  printf("Database: %s\n", database);
  printf("Output:   %s\n", output);
  printf("Mode:     %s\n", mode);
  if (strcmp(sql, "") != 0)   printf("Sql:      %s\n", sql);
  if (strcmp(table, "") != 0) printf("Table:    %s\n", table);
  printf("\n");

  // check for errors
  bool error = false;
  if (strcmp(database, "") == 0)
  {
    error = true;
    printf("Error: no database name provided.\n");
  }
  if (strcmp(output, "") == 0 and strcmp(mode, "screen") != 0)
  {
    error = true;
    printf("Error: no output filename provided.\n");
  }
  if (strcmp(mode, "") == 0)
  {
    error = true;
    printf("Error: no mode provided nor detected from output filename.\n");
  }

  if (strcmp(sql, "") == 0 and strcmp(table, "") == 0)
  {
    error = true;
    printf("Error: no table name or sql query provided.\n");
  }

  if (error == false)
  {
    printf("Busy...\n");

    bool success = false;
    SqliteExport* se = 0;

    if (strcmp(mode, "tabs") == 0)   se = new SqliteExportTabs();
    if (strcmp(mode, "csv") == 0)    se = new SqliteExportCsv();
    if (strcmp(mode, "xls") == 0)    se = new SqliteExportXls();
    if (strcmp(mode, "html") == 0)   se = new SqliteExportHtml();
    if (strcmp(mode, "screen") == 0) se = new SqliteExportScreen();

    if (se != 0)
    {
      // create the query selecting a complete table, or copy the provided sql code
      char query[1024] = "";
      if (strcmp(table, "") != 0) sprintf(query, "SELECT * FROM '%.255s';", table);
      if (strcmp(sql, "") != 0)   strncpy(query, sql, 1024);

      // execute the export
      success = se->DoExport (database, output, query);
      if (success)
        printf("Done\n");
      else
        printf("Error: %s\n", se->LastError());

      delete se;
      se = 0;
    }
    else
    {
      printf("Error: unknown mode \"%.255s\". Choose tabs, csv, xls, or html.\n", mode);
      success = false;
    }
  }
  else
  {
    printf("\n");
    printf("Enter \"sqlite_export -help\" for information about usage of the program.\n");
  }
  printf("\n");

  return 0;
}

