
#include "SqliteExport.h"

/**
 * Constructor
 */
SqliteExport::SqliteExport()
  : file(0)
{
  strcpy(error, "");
}

/**
 * Destructor
 */
SqliteExport::~SqliteExport()
{
  Close();
}

/**
 * Export the given sql command
 * Example usage:
 *   DoExport("TestDb.db", "myTable.txt", "SELECT * FROM myTable;");
 * @param database  The sqlite database
 * @param output    The output filename
 * @param sql       A select sql query to retrieve the data you want to export
 * @return success  True if export was succesful, False if not. If false, you
 *                  can retrieve the last error via the function lastError()
 */
bool SqliteExport::DoExport(const char database[], const char output[], const char sql[])
{
  sqlite3 *db = 0;
  int rc = 0;

  // check whether the database exists.
  if (!FileExists(database))
  {
    sprintf(error, "Database \"%.255s\" does not exist.", database);
    return false;
  }

  // open the database
  rc = sqlite3_open(database, &db);
  if( rc ){
    strncpy(error, sqlite3_errmsg(db), MAXLEN);
    sqlite3_close(db);
    return false;
  }

  // Execute sql command
  int sqllen = strlen(sql);
  sqlite3_stmt *ppStmt = 0;         // OUT: Statement handle
  const char **pzTail = 0;          // OUT: Pointer to unused portion of sql
  rc = sqlite3_prepare_v2(db, sql, sqllen, &ppStmt, pzTail);
  if( rc!=SQLITE_OK )
  {
    strncpy(error, sqlite3_errmsg(db), MAXLEN);
    sqlite3_close(db);
    return false;
  }

  // open file where to export the data
  bool opened = Open(output);
  if (!opened)
  {
    sprintf(error, "Could not open file \"%.255s\"", output);
    rc = sqlite3_finalize(ppStmt);
    sqlite3_close(db);
    return false;
  }
  WriteBegin();

  // print column names
  WriteRowStart();
  int row = 0;
  int colNum = sqlite3_column_count(ppStmt);
  for (int col = 0; col < colNum; col++)
  {
    if (col > 0)
    {
      WriteRowBetween();
    }

    const char* colName = sqlite3_column_name(ppStmt, col);
    WriteFieldName(row, col, colName);
  }
  WriteRowEnd();

  // print all fields, row by row
  row = 1;
  do
  {
    rc = sqlite3_step(ppStmt);

    if (rc == SQLITE_ROW)
    {
      WriteRowStart();
      for (int col = 0; col < colNum; col++)
      {
        if (col > 0)
        {
          WriteRowBetween();
        }

        int colType = sqlite3_column_type(ppStmt, col);
        switch(colType)
        {
          case SQLITE_INTEGER: WriteField(row, col,               sqlite3_column_int  (ppStmt, col)); break;
          case SQLITE_FLOAT:   WriteField(row, col,               sqlite3_column_double(ppStmt, col)); break;
          case SQLITE_TEXT:    WriteField(row, col, (const char*) sqlite3_column_text(ppStmt, col)); break;
          case SQLITE_BLOB:    WriteField(row, col, "[Blob]"); break;
          case SQLITE_NULL:    WriteField(row, col); break;
        }
      }
      WriteRowEnd();
    }
    row++;
  }
  while (rc != SQLITE_DONE);

  WriteEnd();
  Close();

  rc = sqlite3_finalize(ppStmt);
  sqlite3_close(db);
  return true;
}

/// Returns true if a file with the given filename exists. Else returns false.
bool SqliteExport::FileExists(const char* filename)
{
  FILE* temp = fopen (filename, "r");
  if (temp != 0)
  {
    fclose(temp);
    return true;
  }
  return false;
}


/// Returns a vector containing the names of all tables in the
/// provided database. Returns an empty vector when an error
/// occurred. Use LastError() to retrieve the last error.
vector<string> SqliteExport::GetTables(const char* database)
{
  vector<string> tables;

  const char sql[] = "SELECT name FROM sqlite_master WHERE type='table';";
  sqlite3 *db = 0;
  int rc = 0;

  if (database == 0)
  {
    sprintf(error, "No database name provided.");
    return tables;
  }

  // check whether the database exists.
  if (!FileExists(database))
  {
    sprintf(error, "Database \"%.255s\" does not exist.", database);
    return tables;
  }

  // open the database
  rc = sqlite3_open(database, &db);
  if( rc ){
    strncpy(error, sqlite3_errmsg(db), MAXLEN);
    sqlite3_close(db);
    return tables;
  }

  // Execute sql command
  int sqllen = strlen(sql);
  sqlite3_stmt *ppStmt = 0;         // OUT: Statement handle
  const char **pzTail = 0;          // OUT: Pointer to unused portion of sql
  rc = sqlite3_prepare_v2(db, sql, sqllen, &ppStmt, pzTail);
  if( rc!=SQLITE_OK )
  {
    strncpy(error, sqlite3_errmsg(db), MAXLEN);
    sqlite3_close(db);
    return tables;
  }

  do
  {
    rc = sqlite3_step(ppStmt);

    if (rc == SQLITE_ROW)
    {
      string tablename = "";
      tablename = (const char*) sqlite3_column_text(ppStmt, 0);

      tables.push_back(tablename);
    }
  }
  while (rc != SQLITE_DONE);

  rc = sqlite3_finalize(ppStmt);
  sqlite3_close(db);

  return tables;
}


/// Returns the last error
const char* SqliteExport::LastError() const
{
  return error;
}

/// Open a file to writhe the data to
bool SqliteExport::Open(const char* filename)
{
  file = fopen (filename,"w");
  return (file != 0);
}

/// Close the file
void SqliteExport::SqliteExport::Close()
{
  if (file != 0)
  {
    fclose(file);
    file = 0;
  }
}

/// For the tabs format, write string to file taking into account escape
/// characters for tab '\t' and return '\n'
void SqliteExportTabs::WriteString(const char* value)
{
  const char* v = value;
  while (*v != 0)
  {
    switch (*v)
    {
      case '\t': putc('\\', file); putc('t', file); break;
      case '\n': putc('\\', file); putc('n', file); break;
      default: putc(*v, file); break;
    }
    v++;
  }
}

/// For the csv format, write string to file taking into account escape
/// character for double quote "
void SqliteExportCsv::WriteString(const char* value)
{
  const char* v = value;
  putc('\"', file);  // start quote
  while (*v != 0)
  {
    if (*v == '\"') putc('\\', file);
    putc(*v, file);
    v++;
  }
  putc('\"', file);  // end quote
}
