# compile for use als standalone executable

gcc -c sqlite3.c -ldl -lpthread -o sqlite3.o  # only once needed to compile!
g++ -c sqlite_test.cpp -o sqlite_test.o
g++ sqlite_test.o sqlite3.o -ldl -lpthread -o sqlite_test_standalone

