/**
sqlite_export

This program enables you to easily export data from an sqlite to tabs, csv,
xls, or html format.

REMARKS
To compile sqlite3.c on linux, you have to use:
  gcc -c sqlite3.c -ldl -lpthread -o sqlite3.o
It is important NOT to include the compiler option -O2 (optimize for speed),
this gives errors. Furthermore, you have to link to dl and pthread

*/


#ifndef SQLITEEXPORT_H
#define SQLITEEXPORT_H

#include <stdio.h>
#include <cstring>
#include <vector>
#include <string>
#include "sqlite3.h"

#include "Excel.h"

#define MAXLEN 1024

using namespace std;

class SqliteExport
{
public:
  SqliteExport();
  virtual ~SqliteExport();

  bool DoExport(const char database[], const char output[], const char sql[]);

  const char* LastError() const;

  virtual bool Open(const char* filename);
  virtual void Close();

  virtual void WriteBegin() = 0;
  virtual void WriteEnd() = 0;
  virtual void WriteRowStart() = 0;
  virtual void WriteRowBetween() = 0;
  virtual void WriteRowEnd() = 0;
  virtual void WriteFieldName(const int row, const int col, const char* value) = 0;
  virtual void WriteField(const int row, const int col, const int value) = 0;
  virtual void WriteField(const int row, const int col, const double value) = 0;
  virtual void WriteField(const int row, const int col, const char* value) = 0;
  virtual void WriteField(const int row, const int col) = 0;  // (empty field)

  vector<string> GetTables(const char* database);

protected:
  bool FileExists(const char* filename);
  FILE* file;
  char error[MAXLEN];
};

class SqliteExportTabs : public SqliteExport
{
  void WriteBegin()      {}
  void WriteEnd()        {}
  void WriteRowStart()   {}
  void WriteRowBetween() {fprintf(file, "\t");}
  void WriteRowEnd()     {fprintf(file, "\n");}
  void WriteFieldName(const int row, const int col, const char* value) {WriteString(value);}
  void WriteField(const int row, const int col, const int value)       {fprintf(file, "%i", value);}
  void WriteField(const int row, const int col, const double value)    {fprintf(file, "%g", value);}
  void WriteField(const int row, const int col, const char* value)     {WriteString(value);}
  void WriteField(const int row, const int col)                        {}

private:
  void WriteString(const char* value);
};

class SqliteExportCsv : public SqliteExport
{
  void WriteBegin()      {}
  void WriteEnd()        {}
  void WriteRowStart()   {}
  void WriteRowBetween() {fprintf(file, ",");}
  void WriteRowEnd()     {fprintf(file, "\n");}
  void WriteFieldName(const int row, const int col, const char* value) {WriteString(value);}
  void WriteField(const int row, const int col, const int value)       {fprintf(file, "%i", value);}
  void WriteField(const int row, const int col, const double value)    {fprintf(file, "%g", value);}
  void WriteField(const int row, const int col, const char* value)     {WriteString(value);}
  void WriteField(const int row, const int col)                        {}

private:
  void WriteString(const char* value);
};

class SqliteExportXls : public SqliteExport
{
  bool Open(const char* filename) {return excel.Open(filename);}
  void Close()                    {excel.Close();}

  void WriteBegin()      {excel.Begin();}
  void WriteEnd()        {excel.End();}
  void WriteRowStart()   {}
  void WriteRowBetween() {}
  void WriteRowEnd()     {}
  void WriteFieldName(const int row, const int col, const char* value) {excel.Write(row, col, value);}
  void WriteField(const int row, const int col, const int value)       {excel.Write(row, col, value);}
  void WriteField(const int row, const int col, const double value)    {excel.Write(row, col, value);}
  void WriteField(const int row, const int col, const char* value)     {excel.Write(row, col, (const char*)value);}
  void WriteField(const int row, const int col)                        {}

private:
  Excel excel;
};

class SqliteExportHtml : public SqliteExport
{
  void WriteBegin()      {fprintf(file, "<html>\n<body>\n<table>\n");}
  void WriteEnd()        {fprintf(file, "</table>\n</body>\n</html>\n");}
  void WriteRowStart()   {fprintf(file, "<tr>");}
  void WriteRowBetween() {}
  void WriteRowEnd()     {fprintf(file, "</tr>\n");}
  void WriteFieldName(const int row, const int col, const char* value) {fprintf(file, "<th>%s</th>", value);}
  void WriteField(const int row, const int col, const int value)       {fprintf(file, "<td>%i</td>", value);}
  void WriteField(const int row, const int col, const double value)    {fprintf(file, "<td>%g</td>", value);}
  void WriteField(const int row, const int col, const char* value)     {fprintf(file, "<td>%s</td>", value);}
  void WriteField(const int row, const int col)                        {fprintf(file, "<td></td>");}
};

class SqliteExportScreen : public SqliteExport
{
  bool Open(const char* filename) {return false;} // this function should not be used for screen
  void Close()                    {}              // this function should not be used for screen

  void WriteBegin()      {printf("\n");}
  void WriteEnd()        {printf("\n");}
  void WriteRowStart()   {}
  void WriteRowBetween() {printf("\t");}
  void WriteRowEnd()     {printf("\n");}
  void WriteFieldName(const int row, const int col, const char* value) {printf("%s", value);}
  void WriteField(const int row, const int col, const int value)       {printf("%i", value);}
  void WriteField(const int row, const int col, const double value)    {printf("%g", value);}
  void WriteField(const int row, const int col, const char* value)     {printf("%s", value);}
  void WriteField(const int row, const int col)                        {}
};

#endif
