# compile for use with sqlite3 library 
g++ -o sqlite_test_lib sqlite_test.cpp -lsqlite3
